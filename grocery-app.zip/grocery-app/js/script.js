let searchForm = document.querySelector('.search-form');

document.querySelector('#search-btn').onclick = () =>{
    searchForm.classList.toggle('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let shoppingCart = document.querySelector('.shopping-cart');

document.querySelector('#cart-btn').onclick = () =>{
    shoppingCart.classList.toggle('active');
    searchForm.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let loginForm = document.querySelector('.login-form');

document.querySelector('#login-btn').onclick = () =>{
    loginForm.classList.toggle('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    navbar.classList.remove('active');
}

let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
}

window.onscroll = () =>{
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}



function increaseQuantity() {
  let input = document.getElementById('quantity');
  let value = parseInt(input.value);
  input.value = value + 1;
  
}

function decreaseQuantity() {
  let input = document.getElementById('quantity');
  let value = parseInt(input.value);
  if (value > 1) {
    input.value = value - 1;
  }
}

let cart = [];
let total = 0;

function addToCart(productName, price, quantityId) {
  const quantityInput = document.getElementById(quantityId);
  const quantity = parseInt(quantityInput.value);

  if (quantity <= 0 || isNaN(quantity)) {
    alert("Please enter a valid quantity.");
    return;
  }

  const item = {
    name: productName,
    price: price,
    quantity: quantity,
    total: price * quantity
  };

  cart.push(item);
  total += item.total;

  updateCart();
}

function updateCart() {
  const cartList = document.getElementById("cart-items");
  const totalSpan = document.getElementById("total");

  cartList.innerHTML = "";
  cart.forEach(item => {
    const li = document.createElement("li");
    li.textContent = `${item.name} x ${item.quantity} = ₹${item.total}`;
    cartList.appendChild(li);
  });

  totalSpan.textContent = total;
}

function addToCart(productName, price, quantityId) {
  const quantityInput = document.getElementById(quantityId);
  const quantity = parseInt(quantityInput.value);

  if (quantity <= 0 || isNaN(quantity)) {
      alert("Please enter a valid quantity.");
      return;
  }

  fetch("add_to_cart.php", {
      method: "POST",
      headers: {
          "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `productName=${encodeURIComponent(productName)}&price=${price}&quantity=${quantity}`
  })
  .then(response => response.text())
  .then(data => {
      alert(data); // show response from PHP
  })
  .catch(error => {
      console.error("Error:", error);
      alert("Something went wrong!");
  });
}


function loadProducts() {
  const category = document.getElementById('category-select').value;
  const url = category ? `fetch_products.php?category=${category}` : `fetch_products.php`;

  fetch(url)
      .then(response => response.json())
      .then(data => {
          const container = document.getElementById('product-container');
          container.innerHTML = "";
          data.forEach(product => {
              container.innerHTML += `
                  <div class="product">
                      <img src="${product.image}" alt="${product.name}">
                      <h3>${product.name}</h3>
                      <p>₹${product.price}</p>
                      <button>Add to Cart</button>
                  </div>
              `;
          });
      });
}

// Load all products on page load
window.onload = loadProducts;


var swiper = new Swiper(".product-slider", {
    loop:true,
    spaceBetween: 20,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    centeredSlides: true,
    breakpoints: {
      0: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1020: {
        slidesPerView: 3,
      },
    },
});

var swiper = new Swiper(".review-slider", {
    loop:true,
    spaceBetween: 20,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    centeredSlides: true,
    breakpoints: {
      0: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1020: {
        slidesPerView: 3,
      },
    },
});