<?php
$host = "localhost";
$user = "root";
$password = ""; // default for XAMPP
$db = "grocery_store";

// Connect to database
$conn = new mysqli($host, $user, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// Read POST data
$productName = $_POST['productName'];
$price = $_POST['price'];
$quantity = $_POST['quantity'];

$sql = "INSERT INTO cart_items (product_name, price, quantity) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sdi", $productName, $price, $quantity);

if ($stmt->execute()) {
    echo "✅ Product added to cart!";
} else {
    echo "❌ Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
