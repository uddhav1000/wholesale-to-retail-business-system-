<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "grocery_store";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$category = $_GET['category'] ?? '';

$stmt = $conn->prepare("SELECT * FROM products WHERE category = ?");
$stmt->bind_param("s", $category);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo ucfirst($category); ?> - Products</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1><?php echo ucfirst($category); ?> Products</h1>

<div class="products">
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="product">
            <img src="<?php echo $row['image']; ?>" alt="">
            <h3><?php echo $row['name']; ?></h3>
            <p>₹<?php echo $row['price']; ?></p>
            <button>Add to Cart</button>
        </div>
    <?php endwhile; ?>
</div>

</body>
</html>
